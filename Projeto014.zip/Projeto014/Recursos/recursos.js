// importar a biblioteca q use o protocolo http

const http = require('http')
const url = require('url')
const fs = require('fs')

function readFile(response, file){
    fs.readFile(file,function(err, data){
        response.end(data)
    })
}

// criar a função que vai trabalhar no servidor

var callback = function(request, response) {

    var parts = url.parse(request.url)
    var path = parts.path
    
    if (parts.path == "/"){
        response.writeHead(200, {"Content-type" : "text/html"})
        readFile(response, "index.html")
   
    }else if (parts.path == '/recursos/docx' ){
        response.writeHead(200, {"Content-type" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document"})
        readFile(response, "lorem.docx")

    }else if (parts.path == '/recursos/json' ){
        response.writeHead(200, {"Content-type" : "application/json"})
        readFile(response, "cadastro.json")

    
    }else if (parts.path == '/recursos/jpeg' ){
        response.writeHead(200, {"Content-type" : "image/jpeg"})
        readFile(response, "fusca.jpeg")

    
    }else if (parts.path == '/recursos/mp3' ){
        response.writeHead(200, {"Content-type" : "audio/mp3"})
        readFile(response, "Audio.mp3")

    
    }else if (parts.path == '/recursos/mp4' ){
        response.writeHead(200, {"Content-type" : "video/mp4"})
        readFile(response, "video.mp4")


    }else if (parts.path == '/recursos/md' ){
        response.writeHead(200, {"Content-type" : "text/markdown"})
        readFile(response, "texto.md")


    }else {
        response.writeHead(200, {"Content-type" : "text/html"})
        readFile(response, "Site404.html")
    
    }
    
}

// criar o servidor

var server = http.createServer(callback) 
server.listen(3000)
console.log("[SERVER - OK] ...  Servidor montado em http://localhost:3000")