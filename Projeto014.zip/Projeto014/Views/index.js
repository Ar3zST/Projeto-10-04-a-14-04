// importar a biblioteca q use o protocolo http

const http = require('http')
const url = require('url')
const fs = require('fs')

function readFile(response, file){
    fs.readFile(file,function(err, data){
        response.end(data)
    })
}

// criar a função que vai trabalhar no servidor

var callback = function(request, response) {

    var parts = url.parse(request.url)
    var path = parts.path
    
    if (parts.path == "/"){
        response.writeHead(200, {"Content-type" : "text/html"})
        readFile(response, "index.html")
   
    }else if (parts.path == '/views/contato' ){
        response.writeHead(200, {"Content-type" : "text/html"})
        readFile(response, "contato.html")

    }else if (parts.path == '/views/produtos' ){
        response.writeHead(200, {"Content-type" : "text/html"})
        readFile(response, "produtos.html")

    
    }else if (parts.path == '/views/catalogos' ){
        response.writeHead(200, {"Content-type" : "text/html"})
        readFile(response, "catalogos.html")

    }else {
        response.writeHead(200, {"Content-type" : "text/html"})
        readFile(response, "Site404.html")
    
    }
    
}
// criar o servidor

var server = http.createServer(callback) 
server.listen(3000)
console.log("[SERVER - OK] ...  Servidor montado em http://localhost:3000")